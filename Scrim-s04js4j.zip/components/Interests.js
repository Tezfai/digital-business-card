import React from "react";

export default function Interests() {
  return (
    <div className="block">
      <h2>Interests</h2>
      <p>
        I enjoy exploring new tech and software tools, spending time on video games, and learning how different technologies work. Outside of coding, I also like playing Yu-Gi-Oh! as a fun way to relax.
      </p>
    </div>
  );
}
